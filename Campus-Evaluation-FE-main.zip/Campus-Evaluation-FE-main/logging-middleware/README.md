## Logging Middleware
